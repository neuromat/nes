"""ds"""
from __future__ import absolute_import, print_function
from socket import error
__revision__ = '$Id: socketerror_import.py,v 1.2 2005-12-28 14:58:22 syt Exp $'

print(error)
