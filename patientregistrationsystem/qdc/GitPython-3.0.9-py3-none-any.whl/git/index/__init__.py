"""Initialize the index package"""
# flake8: noqa
from __future__ import absolute_import

from .base import *
from .typ import *
