from .cli import cli


# Module API

if __name__ == "__main__":
    cli()
