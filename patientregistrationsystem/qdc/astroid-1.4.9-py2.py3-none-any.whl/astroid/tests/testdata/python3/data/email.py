"""fake email module to test absolute import doesn't grab this one"""
