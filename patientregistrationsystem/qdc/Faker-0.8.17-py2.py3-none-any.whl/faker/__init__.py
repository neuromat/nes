VERSION = '0.8.17'

from faker.generator import Generator
from faker.factory import Factory

Faker = Factory.create
