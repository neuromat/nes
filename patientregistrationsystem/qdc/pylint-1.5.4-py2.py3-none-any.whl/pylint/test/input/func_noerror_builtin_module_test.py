"""test import from a builtin module"""

from __future__ import absolute_import
from math import log10

__revision__ = None


def log10_2():
    """bla bla bla"""
    return log10(2)
